# Count my blocks (Fabric, Minecraft 1.21.11)

1. Hold a **golden axe**.
2. Right-click the first corner block.
3. Look at the opposite corner: the total updates live above your hotbar.
4. Right-click it to lock the count. Right-click again to start a new one, or put the axe away (switch slot) to reset.

Shows total blocks, size (X x Y x Z) and stacks + remainder. Requires Fabric API.

## License and branding

The code is released under the MIT License (see `LICENSE`).
The name "Count my blocks" and the mod's icon are not covered by that license: please don't reuse them for your own or modified versions.
